This is a demo for the minimodule "Why Do the Rich Get Richer? And What Does It Have to Do with Recommendation Algorithms?"

The python simulator of the boards is in main.py 

Have fun!
